import java.sql.*;
import java.util.Scanner;

public class Course {

    private final String url = "jdbc:postgresql://localhost:5432/HealthandFitnessDB";
    private final String user = "postgres";
    private final String password = "postgres";

    // get all group course info
    public void viewAllGroupLesson() {
        String SQL = "SELECT * FROM Group_Lesson";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement pstmt = conn.createStatement()) {
            ResultSet rs = pstmt.executeQuery(SQL);

            while (rs.next()){
                int group_lesson_id = rs.getInt("group_lesson_id");
                String group_lesson_name = rs.getString("group_lesson_name");
                String description  = rs.getString("description");
                int duration  = rs.getInt("duration");
                int max_numbers  = rs.getInt("max_numbers");
                float price  = rs.getFloat("price");
                Date start_date = rs.getDate("start_date");

                System.out.println("Group lesson ID: " + group_lesson_id );
                System.out.println("Group lesson name: " + group_lesson_name );
                System.out.println("description: " + description );
                System.out.println("duration: " + duration );
                System.out.println("Max numbers: " + max_numbers );
                System.out.println("Price: " + price );
                System.out.println("Date: " + start_date );
                System.out.println();

            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }

    // get all group course info
    public void viewIAllOtherActives() {
        String SQL = "SELECT * FROM  Other_Actives";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement pstmt = conn.createStatement()) {
            ResultSet rs = pstmt.executeQuery(SQL);

            while (rs.next()){
                int others_id = rs.getInt("others_id");
                String others_name = rs.getString("others_name");
                String description  = rs.getString("description");
                int duration  = rs.getInt("duration");
                int max_numbers  = rs.getInt("max_numbers");
                float price  = rs.getFloat("price");
                Date date = rs.getDate("date");

                System.out.println("Other ID: " + others_id );
                System.out.println("Others name: " + others_name );
                System.out.println("description: " + description );
                System.out.println("duration: " + duration );
                System.out.println("Max numbers: " + max_numbers );
                System.out.println("Price: " + price );
                System.out.println("Date: " + date );
                System.out.println();

            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }


    public static void main(String[] args) {
        Course course = new Course();
        Scanner scanner = new Scanner(System.in);

        // select all group lesson
        System.out.println("Would you like to view all information about group lesson (yes/no)");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            course.viewAllGroupLesson();
        }


        // select all other actives
        System.out.println("Would you like to view all information about others lesson (yes/no)");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            course.viewIAllOtherActives();
        }

        scanner.close();
    }
}

