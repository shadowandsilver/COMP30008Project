import java.sql.*;
import java.util.Scanner;

public class Coaches {

    private final String url = "jdbc:postgresql://localhost:5432/HealthandFitnessDB";
    private final String user = "postgres";
    private final String password = "postgres";

    // select all rooms' info
    public void getCoaches(int coachesID) {

        String SQL = "SELECT * FROM Coaches WHERE coach_id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {
             pstmt.setInt(1, coachesID);
            ResultSet rs = pstmt.executeQuery();
             while (rs.next()){

                int coach_id = rs.getInt("coach_id");
                String first_name =rs.getString("first_name");
                String last_name =rs.getString("last_name");
                String sex = rs.getString("sex");
                Date Join_date = rs.getDate("Join_date");
                String email = rs.getString("email");
                String phone = rs.getString("phone");

                System.out.println("Coach ID: " + coach_id );
                System.out.println("Name: " + first_name + " " + last_name );
                System.out.println("Sex: " + sex );
                System.out.println("Join Date: " + Join_date );
                System.out.println("Email: " + email  + " Phone: " + phone);
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }


    public static void main(String[] args) {
        Coaches coach = new Coaches();
        Scanner scanner = new Scanner(System.in);

        // select all students
        System.out.println("Would you like to select your coach's information? (yes/no)");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            coach.getCoaches(2);
        }

        scanner.close();
    }
}

