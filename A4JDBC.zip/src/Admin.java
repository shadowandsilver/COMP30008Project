import java.sql.*;
import java.util.Scanner;

public class Admin {

    private final String url = "jdbc:postgresql://localhost:5432/HealthandFitnessDB";
    private final String user = "postgres";
    private final String password = "postgres";

    // select all rooms' info
    public void getRooms() {
        String SQL = "SELECT * FROM rooms";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement pstmt = conn.createStatement()) {
            ResultSet rs = pstmt.executeQuery(SQL);

            while (rs.next()){
                int room_id = rs.getInt("room_id");
                int status =rs.getInt("status");

                System.out.println("Room ID: " + room_id );
                if (status == 0){
                    System.out.println("Status: empty" );
                }else{
                    System.out.println("Status: using" );
                }

            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }

    // get all instruments installing condition
    public void viewInstallingInstruments() {
        String SQL = "SELECT * FROM Install_Instruments";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement pstmt = conn.createStatement()) {
            ResultSet rs = pstmt.executeQuery(SQL);

            while (rs.next()){
                int rooms_id = rs.getInt("rooms_id");
                int instruments_id = rs.getInt("instruments_id");

                System.out.println("Room ID: " + rooms_id );
                System.out.println("Instruments ID: " + instruments_id );

            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }

//    install instruments in rooms
public void installstruments(int instrumentID, int roomID) {
    String SQL = "INSERT INTO Install_Instruments(instruments_id , rooms_id) VALUES(?,?)";

    try (Connection conn = DriverManager.getConnection(url, user, password);
         PreparedStatement pstmt = conn.prepareStatement(SQL)) {

        pstmt.setInt(1, instrumentID);
        pstmt.setInt(2, roomID);
        pstmt.executeUpdate();
        System.out.println("instruments install successfully!");

    } catch (SQLException ex) {
        System.out.println(ex.getMessage());
    }
}

//Unloading instruments
public void unloadingInstruments(int instrumentID) {
    String SQL = "DELETE FROM Install_Instruments WHERE instruments_id=?";

    try (Connection conn = DriverManager.getConnection(url, user, password);
         PreparedStatement pstmt = conn.prepareStatement(SQL)) {

        pstmt.setInt(1, instrumentID);
        pstmt.executeUpdate();
        System.out.println("Instruments deleted!");

    } catch (SQLException ex) {
        System.out.println(ex.getMessage());
    }
}

    // select all instruments' info
    public void getInstruments() {
        String SQL = "SELECT * FROM Instruments";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement pstmt = conn.createStatement()) {
             ResultSet rs = pstmt.executeQuery(SQL);

            while (rs.next()){
                int instrument_id = rs.getInt("instrument_id");
                String instrument_name  =rs.getString("instrument_name");
                Date purchase_date = rs.getDate("purchase_date");
                Date last_check_date = rs.getDate("last_check_date");

                System.out.println("Instrument ID: " + instrument_id );
                System.out.println("Instrument Name: " + instrument_name );
                System.out.println("Purchase Date: " + purchase_date );
                System.out.println("Last Check Date: " + last_check_date );
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }


    public static void main(String[] args) {
        Admin admin = new Admin();
        Scanner scanner = new Scanner(System.in);

        // select all members
        System.out.println("Would you like to manage rooms? (yes/no)");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            admin.getRooms();
        }

        //select all instruments
        System.out.println("Would you like to manage instruments? (yes/no)");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            admin.getInstruments();
        }

        // view all instruments condition
        System.out.println("Would you like to view instruments intalling condition? (yes/no)");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            admin.viewInstallingInstruments();
        }

        //install instrument
        System.out.println("Would you like to install instruments? (yes/no)");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            System.out.println("Please Input room ID: ");
            int roomidinput = scanner.nextInt();
            System.out.println("Please Input Instrument ID: ");
            int instrumentidinput = scanner.nextInt();
            admin.installstruments(instrumentidinput,roomidinput);
        }

        //unloading instrument
        System.out.println("Would you like to unloading instruments? (yes/no)");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            System.out.println("Please Input Instrument ID: ");
            int instrumentunloading = scanner.nextInt();
            admin.unloadingInstruments(instrumentunloading);
        }
        scanner.close();
    }
}