import java.sql.*;
import java.util.Scanner;

public class Member {

    private final String url = "jdbc:postgresql://localhost:5432/HealthandFitnessDB";
    private final String user = "postgres";
    private final String password = "postgres";

    // select your member's info
    public void getMembers(int memberID) {
        String SQL = "SELECT * FROM members WHERE member_id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {
             pstmt.setInt(1, memberID);
             ResultSet rs = pstmt.executeQuery();
            while (rs.next()){

                    int member_id = rs.getInt("member_id");
                    String first_name =rs.getString("first_name");
                    String last_name =rs.getString("last_name");
                    int loyalty_point = rs.getInt("loyalty_point");
                    String Personal_goal = rs.getString("Personal_goal");
                    String Exercise_routines = rs.getString("Exercise_routines");
                    String email = rs.getString("email");
                    String phone = rs.getString("phone");
                    System.out.println("Member ID: " + member_id );
                    System.out.println("Name: " + first_name + " " + last_name );
                    System.out.println("Loyalty Point: " + loyalty_point );
                    System.out.println("Personal Goal: " + Personal_goal );
                    System.out.println("Exercise Routines: " + Exercise_routines );
                    System.out.println("Email: " + email  + " Phone: " + phone);
                }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }


    // select your member's health data
    public void getMembersHealthData(int memberID) {
        String SQL = "SELECT * FROM Health_Data WHERE member_id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {
            pstmt.setInt(1, memberID);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()){

                float height = rs.getFloat("height");
                float weight = rs.getFloat("weight");
                float BMI = rs.getFloat("BMI");
                String sex = rs.getString("sex");
                float age = rs.getFloat("age");
                System.out.println("Height: " + height );
                System.out.println("Weight: " + weight );
                System.out.println("BMI: " + BMI );
                System.out.println("Sex: " + sex );
                System.out.println("Age: " + age );
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    // select your member's Achievemnet
    public void getMembersAchievement(int memberID) {
        String SQL = "SELECT * FROM Member_Achievement WHERE member_id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {
            pstmt.setInt(1, memberID);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()){
                String Achievemnet = rs.getString("Achievemnet");
                System.out.println("Achievemnet: " + Achievemnet );
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }


//    ----------- group lesson -----------

    // get all lesson  taking condition
    public void viewRegistrationGroupLesson(int memberID) {
        String SQL = "SELECT * FROM Registration_Group_Lesson WHERE member_id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {
            pstmt.setInt(1, memberID);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()){

                int member_id = rs.getInt("member_id");
                int group_lesson_id = rs.getInt("group_lesson_id");
                float price  = rs.getFloat("price");
                int fee_status = rs.getInt("fee_status");

                System.out.println("Member ID: " + member_id );
                System.out.println("Group ID: " + group_lesson_id );
                System.out.println("Price: " + price );
                System.out.println("Fee Status: " + fee_status );
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    //    choose group lesson
    public void registrationGroupLesson(int memberID, int groupID) {
        String SQL = "INSERT INTO Registration_Group_Lesson(member_id, group_lesson_id ) VALUES(?,?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setInt(1, memberID);
            pstmt.setInt(2, groupID);
            pstmt.executeUpdate();
            System.out.println("instruments install successfully!");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    //    cancel group lesson
    public void cancelGroupLeason(int groupID) {
        String SQL = "DELETE FROM Registration_Group_Lesson WHERE group_lesson_id=?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setInt(1, groupID);
            pstmt.executeUpdate();
            System.out.println("Group Course Cancel!");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

//    --------------- other actives --------------
    // get all other actives
    public void viewOthersLesson(int memberID) {
        String SQL = "SELECT * FROM Registration_Others_Lesson WHERE member_id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {
            pstmt.setInt(1, memberID);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()){

                int member_id = rs.getInt("member_id");
                int others_id = rs.getInt("others_id");
                float price  = rs.getFloat("price");
                int fee_status = rs.getInt("fee_status");

                System.out.println("Member ID: " + member_id );
                System.out.println("Group ID: " + others_id );
                System.out.println("Price: " + price );
                System.out.println("Fee Status: " + fee_status );
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    // register other actives
    public void registrationOtherActives(int memberID, int otherID) {
        String SQL = "INSERT INTO Registration_Others_Lesson(member_id, group_lesson_id ) VALUES(?,?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setInt(1, memberID);
            pstmt.setInt(2, otherID);
            pstmt.executeUpdate();
            System.out.println("Add active successfully!");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    //    cancel others actives
    public void cancelthersLesson(int otherID) {
        String SQL = "DELETE FROM Registration_Others_Lesson WHERE others_id=?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setInt(1, otherID);
            pstmt.executeUpdate();
            System.out.println("Other Lesson Cancel!");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

//    ------------------ private lesson ------------------
// get all private lesson info
public void viewPrivateLesson(int memberID) {
    String SQL = "SELECT * FROM Registration_Private_Lesson WHERE member_id = ?";

    try (Connection conn = DriverManager.getConnection(url, user, password);
         PreparedStatement pstmt = conn.prepareStatement(SQL)) {
        pstmt.setInt(1, memberID);
        ResultSet rs = pstmt.executeQuery();
        while (rs.next()){

            int member_id = rs.getInt("member_id");
            int coach_id = rs.getInt("coach_id");
            float price  = rs.getFloat("price");
            int fee_status = rs.getInt("fee_status");

            System.out.println("Member ID: " + member_id );
            System.out.println("Coach ID: " + coach_id );
            System.out.println("Price: " + price );
            System.out.println("Fee Status: " + fee_status );
        }

    } catch (SQLException ex) {
        System.out.println(ex.getMessage());
    }
}

// register private lesson
    public void registrationPrivateLesson(int memberID, int coachID) {
        String SQL = "INSERT INTO Registration_Private_Lesson(member_id, coach_id ) VALUES(?,?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setInt(1, memberID);
            pstmt.setInt(2, coachID);
            pstmt.executeUpdate();
            System.out.println("Add private lesson successfully!");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    //    cancel private actives
    public void cancelPrivateLesson(int privateLessonID) {
        String SQL = "DELETE FROM Registration_Private_Lesson WHERE coach_id=?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setInt(1, privateLessonID);
            pstmt.executeUpdate();
            System.out.println("Other Lesson Cancel!");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public static void main(String[] args) {
        Member member = new Member();
        Scanner scanner = new Scanner(System.in);

        // select all students
        System.out.println("Would you like to select your member's information? (yes/no)");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            member.getMembers(1);
            System.out.println("___________________________");
            member.getMembersHealthData(1);
            System.out.println("___________________________");
            member.getMembersAchievement(1);
            System.out.println();
            System.out.println();
            System.out.println();


//            -------- group lesson ----------
            // check group lesson you have registration
            System.out.println("---------------Group Lesson-----------------");
            System.out.println("Would you like to view registration group lesson? (yes/no)");
            if (scanner.nextLine().equalsIgnoreCase("yes")) {
                member.viewRegistrationGroupLesson(1);
            }
            System.out.println();

            //choose group
            System.out.println("Would you like to choose group course? (yes/no)");
            if (scanner.nextLine().equalsIgnoreCase("yes")) {
                System.out.println("Please Input group ID: ");
                int groupIDinput = scanner.nextInt();
                member.registrationGroupLesson(1,groupIDinput);
            }
            System.out.println();

            //cancel group lesson
            System.out.println("Would you like to cancel group lesson? (yes/no)");
            if (scanner.nextLine().equalsIgnoreCase("yes")) {
                System.out.println("Please Input group ID you want to cancel: ");
                int groupIDcancel = scanner.nextInt();
                member.cancelGroupLeason(groupIDcancel);
            }
            System.out.println();


        //-------------- other actives --------------


            //view other
            System.out.println("---------------Other Actives-----------------");
            System.out.println("Would you like to view all other actives' information? (yes/no)");
            if (scanner.nextLine().equalsIgnoreCase("yes")) {
                member.viewOthersLesson(1);
            }
            System.out.println();

            //register other
            System.out.println("Would you like to choose group course? (yes/no)");
            if (scanner.nextLine().equalsIgnoreCase("yes")) {
                System.out.println("Please Input Other ID: ");
                int otherIDinput = scanner.nextInt();
                member.registrationOtherActives(1,otherIDinput);
            }
            System.out.println();

            //cancel others
            System.out.println("Would you like to cancel others actives? (yes/no)");
            if (scanner.nextLine().equalsIgnoreCase("yes")) {
                System.out.println("Please Input other ID you want to cancel: ");
                int otherIDCancel = scanner.nextInt();
                member.cancelthersLesson(otherIDCancel);
            }
            System.out.println();

//            -------------- private lesson -----------------
            System.out.println("---------------private lesson-----------------");
            //view private lesson
            System.out.println("Would you like to view all private lesson information? (yes/no)");
            if (scanner.nextLine().equalsIgnoreCase("yes")) {
                member.viewPrivateLesson(1);
            }
            System.out.println();

            //register private lesson
            System.out.println("Would you like to choose your private coach? (yes/no)");
            if (scanner.nextLine().equalsIgnoreCase("yes")) {
                System.out.println("Please Input coach ID: ");
                int privateIDinput = scanner.nextInt();
                member.registrationPrivateLesson(1,privateIDinput);
            }
            System.out.println();

            //cancel others
            System.out.println("Would you like to cancel your private lesson? (yes/no)");
            if (scanner.nextLine().equalsIgnoreCase("yes")) {
                System.out.println("Please Input coach ID you want to cancel: ");
                int coachIDCancel = scanner.nextInt();
                member.cancelPrivateLesson(coachIDCancel);
            }
            System.out.println();
    }

        scanner.close();
    }
}
