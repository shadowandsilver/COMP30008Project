import java.util.Scanner;

import static java.lang.System.exit;

public class Main {
    static Scanner sc = new Scanner(System.in);
    static Member member = new Member();
    static Course course = new Course();
    static Coaches coach = new Coaches();

    static Admin admin = new Admin();

    public static void main(String[] args) {
        System.out.println("----------------------------------------");
        System.out.println("----------------------------------------");
        System.out.println("-------Health and Fitness Club!!!-------");
        System.out.println("----------------------------------------");
        System.out.println("----------------------------------------");
        System.out.println();

//   main view
        while (true){
            System.out.println("----------------------------------------");
            System.out.println("------------1. Member System------------");
            System.out.println("------------2. Coach System-------------");
            System.out.println("------------3. Admin System-------------");
            System.out.println("------------0. Exit System--------------");
            System.out.println("----------------------------------------");
            System.out.println();
            System.out.println("Please input your choice: ");
            int choice = sc.nextInt();
            System.out.println();

            if(choice == 1){
                memberSystem();
            }else if(choice == 2){
                coachSystem();
            }else if(choice == 3){
                adminSystem();
            }else if(choice == 0){
                System.out.println("Thank you!");
                exit(0);
            }else{
                System.out.println("Please input correct value");
                System.out.println();
            }
        }

    }

    //        implement
    public static void memberSystem(){
        System.out.println("Welcome to member system! ");

        System.out.println("Do you have a account(yes/no) ? ");
        String choiceLogin = sc.next();
        if(choiceLogin.equals("no")){
//                register
            System.out.println("Please input first name: ");
            String first_name = sc.next();
            System.out.println("Please input last name: ");
            String last_name = sc.next();
            System.out.println("Please input personal goal: ");
            String personal_goal = sc.next();
            System.out.println("Please input exercise routines: ");
            String exercise_routines = sc.next();
            System.out.println("Please input email: ");
            String email = sc.next();
            System.out.println("Please input phone: ");
            String phone = sc.next();
            member.addMember(first_name,last_name,0, personal_goal, exercise_routines, email, phone);

        }else if(choiceLogin.equals("yes")){
//                login
            System.out.println();
            System.out.println("Please input your memberID!");
            int memberID = sc.nextInt();
            member.getMembers(memberID);
            System.out.println("___________________________");
            member.getMembersHealthData(memberID);
            System.out.println("___________________________");
            member.getMembersAchievement(memberID);
            System.out.println();

            while(true){
                System.out.println("------------1. Group Lesson------------");
                System.out.println("------------2. Other Actives-----------");
                System.out.println("------------3. private Lesson----------");
                System.out.println("------------0. Exit ------------");
                System.out.println("Please input your choice: ");
                int choice = sc.nextInt();
                System.out.println();
                if(choice == 1){
                    while (true){
                        System.out.println("------------1. View your group lesson------------");
                        System.out.println("------------2. Add your group lesson-------------");
                        System.out.println("------------3. Cancel your group lesson----------");
                        System.out.println("------------0. Exit operate----------------------");
                        System.out.println("Please input your choice: ");
                        int choiceGroupLesson = sc.nextInt();
                        System.out.println();

                        if(choiceGroupLesson == 1){

                            member.viewRegistrationGroupLesson(memberID);

                        }else if(choiceGroupLesson == 2){
//                        view all course
                            System.out.println("------------All group lesson information---------");
                            course.viewAllGroupLesson();
                            System.out.println("Please input group lesson ID that you like: ");
                            int groupID = sc.nextInt();
                            member.registrationGroupLesson(memberID,groupID);

                        }else if(choiceGroupLesson == 3){
                            System.out.println("Please input group lesson ID that you want to cancel: ");
                            int groupID = sc.nextInt();
                            member.cancelGroupLeason(groupID);

                        }else if(choiceGroupLesson == 0){
                            System.out.println("Thank you!");
                            break;
                        }else{
                            System.out.println("Please input correct value");
                            System.out.println();
                        }
                    }

                }else if(choice == 2){
                    while (true){
                        System.out.println("------------1. View your other actives------------");
                        System.out.println("------------2. Add your other actives-------------");
                        System.out.println("------------3. Cancel your other actives----------");
                        System.out.println("------------0. Exit operate-----------------------");
                        System.out.println("Please input your choice: ");
                        int choiceOtherActive = sc.nextInt();
                        System.out.println();

                        if(choiceOtherActive == 1){

                            member.viewOthersLesson(memberID);

                        }else if(choiceOtherActive == 2){
//                        view all other actives
                            System.out.println("------------All other actives---------");
                            course.viewIAllOtherActives();
                            System.out.println("Please input other actives ID that you like: ");
                            int activeID = sc.nextInt();
                            member.registrationOtherActives(memberID,activeID);

                        }else if(choiceOtherActive == 3){
                            System.out.println("Please input other actives ID that you want to cancel: ");
                            int activeID = sc.nextInt();
                            member.cancelothersLesson(activeID);

                        }else if(choiceOtherActive == 0){
                            System.out.println("Thank you!");
                            break;
                        }else{
                            System.out.println("Please input correct value");
                            System.out.println();
                        }
                    }

                }else if(choice == 3){
                    while (true){
                        System.out.println("------------1. View your private lesson------------");
                        System.out.println("------------2. Add your private lesson-------------");
                        System.out.println("------------3. Cancel your private lesson----------");
                        System.out.println("------------0. Exit operate-----------------------");
                        System.out.println("Please input your choice: ");
                        int choicePrivateLesson = sc.nextInt();
                        System.out.println();

                        if(choicePrivateLesson == 1){

                            member.viewPrivateLesson(memberID);

                        }else if(choicePrivateLesson == 2){
//                        view all coaches
                            System.out.println("------------All coaches---------");
                            coach.viewAllCoaches();
                            System.out.println("Please input coach ID that you like: ");
                            int privateID = sc.nextInt();
                            member.registrationPrivateLesson(memberID,privateID);

                        }else if(choicePrivateLesson == 3){
                            System.out.println("Please input coach ID that you want to cancel: ");
                            int privateID = sc.nextInt();
                            member.cancelPrivateLesson(privateID);

                        }else if(choicePrivateLesson == 0){
                            System.out.println("Thank you!");
                            break;
                        }else{
                            System.out.println("Please input correct value");
                            System.out.println();
                        }
                    }
                }else if(choice == 0){
                    System.out.println("Thank you!");
                    break;
                }else{
                    System.out.println("Please input correct value");
                    System.out.println();
                }

            }
        }

    }

    public static void coachSystem(){
        System.out.println("Welcome to coach system! ");

        System.out.println("Please input your coachID!");
        int coachID = sc.nextInt();
        coach.getCoaches(coachID);

        while(true){
            System.out.println("------------1. Group Lesson------------");
            System.out.println("------------2. Other Actives-----------");
            System.out.println("------------3. private Lesson----------");
            System.out.println("------------0. Exit ------------");
            System.out.println("Please input your choice: ");
            int choice = sc.nextInt();
            System.out.println();
            if(choice == 1){
                while (true){
                    System.out.println("------------1. View your group lesson------------");
                    System.out.println("------------2. Add your group lesson-------------");
                    System.out.println("------------3. Cancel your group lesson----------");
                    System.out.println("------------0. Exit operate----------------------");
                    System.out.println("Please input your choice: ");
                    int choiceGroupLesson = sc.nextInt();
                    System.out.println();

                    if(choiceGroupLesson == 1){

                        coach.groupLessonSchedule(coachID);

                    }else if(choiceGroupLesson == 2){
//                        view all course
                        System.out.println("------------All group lesson information---------");
                        course.viewAllGroupLesson();
                        System.out.println("Please input group lesson ID that you like: ");
                        int groupID = sc.nextInt();
                        coach.takeGroupLesson(coachID,groupID);

                    }else if(choiceGroupLesson == 3){
                        System.out.println("Please input group lesson ID that you want to cancel: ");
                        int groupID = sc.nextInt();
                        coach.cancelGroupLesson(groupID);

                    }else if(choiceGroupLesson == 0){
                        System.out.println("Thank you!");
                        break;
                    }else{
                        System.out.println("Please input correct value");
                        System.out.println();
                    }
                }

            }else if(choice == 2){
                while (true){
                    System.out.println("------------1. View your other actives------------");
                    System.out.println("------------2. Add your other actives-------------");
                    System.out.println("------------3. Cancel your other actives----------");
                    System.out.println("------------0. Exit operate-----------------------");
                    System.out.println("Please input your choice: ");
                    int choiceOtherActive = sc.nextInt();
                    System.out.println();

                    if(choiceOtherActive == 1){

                        coach.otherActiveSchdule(coachID);

                    }else if(choiceOtherActive == 2){
//                        view all other actives
                        System.out.println("------------All other actives---------");
                        course.viewIAllOtherActives();
                        System.out.println("Please input other actives ID that you like: ");
                        int activeID = sc.nextInt();
                        coach.takeOtherActives(coachID,activeID);

                    }else if(choiceOtherActive == 3){
                        System.out.println("Please input other actives ID that you want to cancel: ");
                        int activeID = sc.nextInt();
                        coach.cancelOthersLesson(activeID);

                    }else if(choiceOtherActive == 0){
                        System.out.println("Thank you!");
                        break;
                    }else{
                        System.out.println("Please input correct value");
                        System.out.println();
                    }
                }

            }else if(choice == 3){
                while (true){
                    System.out.println("------------1. View your private lesson--------------------");
                    System.out.println("------------2. Member information which you want to see----");
                    System.out.println("------------3. Cancel your private lesson------------------");
                    System.out.println("------------0. Exit operate--------------------------------");
                    System.out.println("Please input your choice: ");
                    int choicePrivateLesson = sc.nextInt();
                    System.out.println();

                    if(choicePrivateLesson == 1){

                        coach.viewPrivateLesson(coachID);

                    }else if(choicePrivateLesson == 2){
                        System.out.println("Please input member ID that you want to find: ");
                        int memberIDCoach = sc.nextInt();
                        member.getMembers(memberIDCoach);

                    }else if(choicePrivateLesson == 3){
                        System.out.println("Please input member ID that you want to cancel: ");
                        int privateID = sc.nextInt();
                        coach.cancelPrivateLesson(privateID);

                    }else if(choicePrivateLesson == 0){
                        System.out.println("Thank you!");
                        break;
                    }else{
                        System.out.println("Please input correct value");
                        System.out.println();
                    }
                }
            }else if(choice == 0){
                System.out.println("Thank you!");
                break;
            }else{
                System.out.println("Please input correct value");
                System.out.println();
            }

        }
    }

    public static void adminSystem(){
        System.out.println("Welcome to admin system! ");

        System.out.println("Please input your admin ID (admin):");
        String adminAccount = sc.next();
        System.out.println("Please input your password (123456):");
        int adminPassword = sc.nextInt();

        if(adminAccount.equals("admin") && adminPassword == 123456){
            while(true){
                System.out.println("------------1. view room-----------------------");
                System.out.println("------------2. View instrument-----------------");
                System.out.println("------------3. view install condition----------");
                System.out.println("------------4. install instrument--------------");
                System.out.println("------------5. unloading instrument--------------");
                System.out.println("------------0. Exit ---------------------------");
                System.out.println("Please input your choice: ");
                int choice = sc.nextInt();
                System.out.println();
                if(choice == 1){
                    System.out.println("------------All room---------------");
                    admin.getRooms();
                }else if(choice == 2){
                    System.out.println("------------All instrument---------");
                    admin.getInstruments();
                }else if(choice == 3){
                    System.out.println("------------Instrument have been install in room---------");
                    admin.viewInstallingInstruments();
                }else if(choice == 4){
                    System.out.println("Please input room ID that you want to choice: ");
                    int roomIDInstall = sc.nextInt();
                    System.out.println("Please input instrument ID that you want to choice: ");
                    int instrumentIDInstall = sc.nextInt();
                    admin.installstruments(instrumentIDInstall,roomIDInstall);
                }else if(choice == 5){
                    System.out.println("Please input Instrument ID: ");
                    int instrumentIDUnloading = sc.nextInt();
                    admin.unloadingInstruments(instrumentIDUnloading);
                }else if(choice == 0){
                    System.out.println("Thank you!");
                    break;
                }else{
                    System.out.println("Please input correct value");
                    System.out.println();
                }

            }
        }else{
            System.out.println("You don't have persimmon!!!");
        }


    }

}