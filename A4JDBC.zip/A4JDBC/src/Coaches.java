import java.sql.*;
import java.util.Scanner;

public class Coaches {

    private final String url = "jdbc:postgresql://localhost:5432/HealthandFitnessDB";
    private final String user = "postgres";
    private final String password = "postgres";

    // select all rooms' info
    public void getCoaches(int coachesID) {

        String SQL = "SELECT * FROM Coaches WHERE coach_id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {
             pstmt.setInt(1, coachesID);
            ResultSet rs = pstmt.executeQuery();
             while (rs.next()){

                int coach_id = rs.getInt("coach_id");
                String first_name =rs.getString("first_name");
                String last_name =rs.getString("last_name");
                String sex = rs.getString("sex");
                Date Join_date = rs.getDate("Join_date");
                String email = rs.getString("email");
                String phone = rs.getString("phone");

                System.out.println("Coach ID: " + coach_id );
                System.out.println("Name: " + first_name + " " + last_name );
                System.out.println("Sex: " + sex );
                System.out.println("Join Date: " + Join_date );
                System.out.println("Email: " + email  + " Phone: " + phone);
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

//    -----------------  takes group lesson  ------------------
    // group lesson schedule
    public void groupLessonSchedule(int groupID) {
        String SQL = "SELECT * FROM Take_Group_Lesson WHERE coach_id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {
            pstmt.setInt(1, groupID);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()){

                int coach_id = rs.getInt("coach_id");
                int group_lesson_id = rs.getInt("group_lesson_id");

                System.out.println("Coach ID: " + coach_id );
                System.out.println("Group lesson ID: " + group_lesson_id );
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

        // takes group lesson
        public void takeGroupLesson(int coachID, int groupLessonID) {
            String SQL = "INSERT INTO Take_Group_Lesson(coach_id, group_lesson_id ) VALUES(?,?)";

            try (Connection conn = DriverManager.getConnection(url, user, password);
                 PreparedStatement pstmt = conn.prepareStatement(SQL)) {

                pstmt.setInt(1, coachID);
                pstmt.setInt(2, groupLessonID);
                pstmt.executeUpdate();
                System.out.println("Add private lesson successfully!");

            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }

        //    cancel private actives
        public void cancelGroupLesson(int groupLessonID) {
            String SQL = "DELETE FROM Take_Group_Lesson WHERE group_lesson_id=?";

            try (Connection conn = DriverManager.getConnection(url, user, password);
                 PreparedStatement pstmt = conn.prepareStatement(SQL)) {

                pstmt.setInt(1, groupLessonID);
                pstmt.executeUpdate();
                System.out.println("Group lesson cancel!");

            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }

//    -------------- takes other actives ---------------
// show other active schedule
public void otherActiveSchdule(int coachID) {
    String SQL = "SELECT * FROM Take_Others_Lesson WHERE coach_id = ?";

    try (Connection conn = DriverManager.getConnection(url, user, password);
         PreparedStatement pstmt = conn.prepareStatement(SQL)) {
        pstmt.setInt(1, coachID);
        ResultSet rs = pstmt.executeQuery();
        while (rs.next()){

            int coach_id = rs.getInt("coach_id");
            int others_id = rs.getInt("others_id");

            System.out.println("Coach ID: " + coach_id );
            System.out.println("Other active ID: " + others_id );
        }

    } catch (SQLException ex) {
        System.out.println(ex.getMessage());
    }
}

    // register other actives
    public void takeOtherActives(int coachID, int otherID) {
        String SQL = "INSERT INTO Take_Others_Lesson(coach_id, others_id ) VALUES(?,?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setInt(1, coachID);
            pstmt.setInt(2, otherID);
            pstmt.executeUpdate();
            System.out.println("Add active successfully!");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    //    cancel others actives
    public void cancelOthersLesson(int otherID) {
        String SQL = "DELETE FROM Take_Others_Lesson WHERE others_id=?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setInt(1, otherID);
            pstmt.executeUpdate();
            System.out.println("Other active Cancel!");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }


    public static void main(String[] args) {
        Coaches coach = new Coaches();
        Scanner scanner = new Scanner(System.in);

        // select all students
        System.out.println("Would you like to select your coach's information? (yes/no)");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            coach.getCoaches(1);
        }


        //-------------- group lesson --------------
        //schedule
        System.out.println("--------------- Group lesson Schedule -----------------");
        System.out.println("Would you like to view all other actives' information? (yes/no)");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            coach.groupLessonSchedule(1);
        }
        System.out.println();

        //take group lesson
        System.out.println("Would you like to choose group course? (yes/no)");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            System.out.println("Please Input group lesson ID: ");
            int groupIDinput = scanner.nextInt();
            coach.takeGroupLesson(1,groupIDinput);
        }
        System.out.println();

        //cancel others
        System.out.println("Would you like to cancel others actives? (yes/no)");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            System.out.println("Please Input group lesson you want to cancel: ");
            int groupIDCancel = scanner.nextInt();
            coach.cancelGroupLesson(groupIDCancel);
        }
        System.out.println();


        //-------------- other actives --------------
        //schedule
        System.out.println("--------------- Other Actives Schedule -----------------");
        System.out.println("Would you like to view all other actives' information? (yes/no)");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            coach.otherActiveSchdule(1);
        }
        System.out.println();

        //take other actives
        System.out.println("Would you like to choose group course? (yes/no)");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            System.out.println("Please Input group lesson ID: ");
            int otherIDinput = scanner.nextInt();
            coach.takeOtherActives(1,otherIDinput);
        }
        System.out.println();

        //cancel others
        System.out.println("Would you like to cancel others actives? (yes/no)");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            System.out.println("Please Input group lesson you want to cancel: ");
            int otherIDCancel = scanner.nextInt();
            coach.cancelOthersLesson(otherIDCancel);
        }
        System.out.println();
        scanner.close();
    }
}

