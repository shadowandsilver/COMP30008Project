import java.sql.*;
import java.util.Scanner;

public class member {
    private final String url = "jdbc:postgresql://localhost:5432/Assignment4";
    private final String user = "postgres";
    private final String password = "postgres";


}
