//codes from teacher's example
//This link is from teacher's Github.
//https://github.com/aorogat/COMP3005_DBMS/tree/main/JavaApplicationPostgreSQL

import java.sql.*;
import java.util.Scanner;


public class DatabaseOperations {

    private final String url = "jdbc:postgresql://localhost:5432/Assignment4";
    private final String user = "postgres";
    private final String password = "postgres";

    // select all students
    public void getAllStudents() {
        String SQL = "SELECT student_id, first_name, last_name, email, enrollment_date FROM students";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement pstmt = conn.createStatement()) {
             ResultSet rs = pstmt.executeQuery(SQL);
             while (rs.next()){
                 int id = rs.getInt("student_id");
                 String firstName = rs.getString("first_name");
                 String lastName = rs.getString("last_name");
                 String Email = rs.getString("email");
                 Date enrollmentDate = rs.getDate("enrollment_date");
                 System.out.println("Student ID: " + id + " Name: " + firstName + " "
                         + lastName + "Email: " + Email + "Date: " + enrollmentDate);
             }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    // Add a student
    public void addStudent(String first_name, String last_name, String email, Date enrollment_date) {
        String SQL = "INSERT INTO students(first_name, last_name, email, enrollment_date) VALUES(?,?,?,?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setString(1, first_name);
            pstmt.setString(2, last_name);
            pstmt.setString(3, email);
            pstmt.setDate(4, enrollment_date);
            pstmt.executeUpdate();
            System.out.println("students added successfully!");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    // Update user's email based on name
    public void updateStudentEmail(int student_id, String new_email) {
        String SQL = "UPDATE students SET email=? WHERE student_id=?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setString(1, new_email);
            pstmt.setInt(2, student_id);
            pstmt.executeUpdate();
            System.out.println("students email updated!");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    // Delete user based on name
    public void deleteStudent(int student_id) {
        String SQL = "DELETE FROM students WHERE student_id=?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setInt(1, student_id);
            pstmt.executeUpdate();
            System.out.println("student deleted!");

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
